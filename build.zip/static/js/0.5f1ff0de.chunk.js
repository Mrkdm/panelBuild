/*! For license information please see 0.5f1ff0de.chunk.js.LICENSE.txt */
(this.webpackJsonpfrontend=this.webpackJsonpfrontend||[]).push([[0],{82:function(n,s,t){"use strict"}}]);
//# sourceMappingURL=0.5f1ff0de.chunk.js.map